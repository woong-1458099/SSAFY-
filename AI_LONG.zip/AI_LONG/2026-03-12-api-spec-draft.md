# 2026-03-12 API Spec Draft

- Added `BackEnd/docs/API_SPEC_DRAFT.md`.
- Wrote API specification in the user's requested format for user, save, inventory, challenge, and asset domains.
- Split the document into `target APIs` and `currently implemented APIs` to match the current backend state.
- Follow-up: refine request/response DTOs and status codes once backend implementation scope is fixed.
