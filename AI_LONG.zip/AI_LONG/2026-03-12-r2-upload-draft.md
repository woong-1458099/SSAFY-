# 2026-03-12 R2 Upload Draft

## Summary
- Added an R2 asset deployment guide for the frontend runtime asset set.
- Added draft shell and PowerShell scripts for uploading `public/assets/game` to Cloudflare R2.

## Files Added
- `FrontEnd/ssafy-maker/docs/conventions/R2_ASSET_DEPLOYMENT.md`
- `FrontEnd/ssafy-maker/scripts/upload-assets-to-r2.sh`
- `FrontEnd/ssafy-maker/scripts/upload-assets-to-r2.ps1`

## Notes
- The draft uses versioned upload targets under `game/releases/<ASSET_VERSION>/`.
- The backend asset manifest should point `ASSET_BASE_URL` to the selected release path after upload verification.
