# 2026-03-12 Challenge Assignment Rename

- Updated challenge API wording from `유저 도전과제 시작` to `유저 도전과제 할당`.
- Touched `BackEnd/docs/API_SPEC_DRAFT.md`, `BackEnd/docs/API_SPEC_DRAFT.txt`, and `BackEnd/docs/API_SPEC_WITH_EXAMPLES.txt`.
- Simplified the endpoint description to assignment-focused language for clarity.
