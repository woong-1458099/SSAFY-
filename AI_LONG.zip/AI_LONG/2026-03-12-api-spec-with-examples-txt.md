# 2026-03-12 API Spec TXT With Examples

- Added `BackEnd/docs/API_SPEC_WITH_EXAMPLES.txt`.
- Restored request/response example JSON in a plain text version for easier copy/paste.
- Kept the simple line-based format while preserving example payloads where available.
