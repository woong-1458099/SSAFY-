# 2026-03-12 Asset Manifest API

## Summary
- Added a backend asset manifest API for Phaser asset loading with R2/CDN.
- Added a classpath JSON manifest that maps logical asset keys to relative asset paths.
- Added configurable asset base URL and manifest version properties.

## API
- `GET /api/public/assets/manifest`

## Notes
- The response is designed so the frontend can combine `baseUrl` with relative paths from the manifest.
- This keeps R2/CDN paths out of hardcoded Phaser scene definitions.
