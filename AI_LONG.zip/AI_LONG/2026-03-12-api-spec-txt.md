# 2026-03-12 API Spec TXT

- Added `BackEnd/docs/API_SPEC_DRAFT.txt`.
- Converted the API specification draft into plain text for easier copy/paste.
- Kept both target APIs and currently implemented APIs in the text version.
