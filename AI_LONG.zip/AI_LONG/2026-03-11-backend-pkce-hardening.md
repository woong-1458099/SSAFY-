# 2026-03-11 Backend PKCE Hardening

## Summary
- Removed the old backend-mediated signup/login flow after switching to frontend PKCE.
- Added Keycloak JWT role mapping for Spring Security authorities.
- Added soft delete blocking and a self-delete endpoint for local user profiles.

## Changes
- Deleted the direct auth controller, auth service, and Keycloak admin/token client code paths.
- Added role extraction from `realm_access.roles` and `resource_access.<client>.roles`.
- Added `DELETE /api/users/me` and blocked deleted users from bootstrap and profile access.

## Files Touched
- `BackEnd/src/main/java/com/example/gameinfratest/config/SecurityConfig.java`
- `BackEnd/src/main/java/com/example/gameinfratest/api/controller/UserController.java`
- `BackEnd/src/main/java/com/example/gameinfratest/service/UserService.java`
- `BackEnd/src/main/java/com/example/gameinfratest/user/UserRepository.java`
