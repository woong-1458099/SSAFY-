# 2026-03-11 Agents Rules Update

## Summary
- Updated `AGENTS.md` to define the repository agent rules.

## Changes
- Added a rule to directly implement code changes when the user requests them.
- Added a rule to record every repository modification as a Markdown note under `AI_LONG/`.

## Files Touched
- `AGENTS.md`
