# 2026-03-11 Swagger Integration

## Summary
- Added Springdoc OpenAPI and Swagger UI to the backend.
- Exposed OpenAPI under `/api/v3/api-docs` and Swagger UI under `/api/swagger-ui.html`.
- Updated security to allow public access to the Swagger and OpenAPI endpoints.

## Files Touched
- `BackEnd/build.gradle`
- `BackEnd/src/main/resources/application.yml`
- `BackEnd/src/main/java/com/example/gameinfratest/config/OpenApiConfig.java`
- `BackEnd/src/main/java/com/example/gameinfratest/config/SecurityConfig.java`

## Operational Note
- External Swagger access depends on the current Nginx `/api` reverse proxy behavior. The route handling should be verified in staging after deployment.
