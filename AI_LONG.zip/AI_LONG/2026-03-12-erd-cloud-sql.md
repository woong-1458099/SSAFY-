# 2026-03-12 ERD Cloud SQL

- Added `BackEnd/docs/erd-cloud-postgresql.sql`.
- Wrote PostgreSQL DDL for ERD Cloud import covering `users`, save files, progress, inventory, challenges, and asset tables.
- Included `created_at`, `updated_at`, and related constraints, foreign keys, unique keys, check constraints, and supporting indexes.
- Follow-up: if this schema is adopted for real migrations, add UUID generation strategy and `updated_at` trigger handling in application or DB layer.
