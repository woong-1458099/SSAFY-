# 2026-03-11 Keycloak Auth Integration

## Summary
- Added backend signup and login APIs for Keycloak-based authentication.
- Added local `users` persistence with timestamps and soft-delete column support.
- Connected the frontend login scene to the backend signup and login APIs.

## Backend Changes
- Added `POST /api/public/users` for signup.
- Added `POST /api/public/auth/login` for login.
- Added Keycloak configuration properties, HTTP client integration, and API exception handling.
- Added `users` entity, repository, and Flyway migration.
- Added CORS configuration for the frontend development origin.

## Frontend Changes
- Added `src/features/auth/api.ts` for signup/login API calls.
- Replaced the mock login scene behavior with real signup and login requests.
- Stored access token, refresh token, and user profile in Phaser registry and `localStorage`.

## Operational Notes
- Backend verification was blocked because Java is not installed and `JAVA_HOME` is not set in the current environment.
- Frontend dependency installation/build verification was blocked because the local environment is using Node 25 / npm 11 while the project requires Node 20 / npm 10.
