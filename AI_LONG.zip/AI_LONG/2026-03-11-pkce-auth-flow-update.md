# 2026-03-11 PKCE Auth Flow Update

## Summary
- Switched the frontend auth flow from backend-mediated login/signup forms to Keycloak Authorization Code with PKCE.
- Added a backend endpoint to bootstrap or fetch the local user profile from the authenticated JWT.

## Frontend Changes
- Added a PKCE helper module for Keycloak redirect, callback handling, code exchange, and local session storage.
- Reworked the login scene so login/signup now redirect to Keycloak hosted pages instead of collecting credentials inside the game client.
- After callback completion, the client calls the backend with the access token to sync the local `users` row.

## Backend Changes
- Added `/api/users/me/bootstrap` and `/api/users/me` protected endpoints.
- Added a `UserService` that upserts or resolves the local user from the JWT `sub` and `email` claims.
- Enabled local JWT resource server defaults for Keycloak-based development.

## Operational Notes
- Local development now expects a Keycloak issuer URI to be reachable, defaulting to `http://localhost:8081/realms/master`.
- Frontend verification is still blocked in this environment because the installed Node and npm versions do not match the project's required engine range.
- Backend compilation is still blocked in this environment because Java and `JAVA_HOME` are not available.
