# 2026-03-12 PostgreSQL ERD Draft

- Added `BackEnd/docs/POSTGRESQL_ERD.md`.
- Documented the currently implemented DB entity (`users`) and a recommended PostgreSQL ERD for save files, inventory, challenges, and asset manifests.
- Based the draft on backend migration/JPA files plus frontend save and gameplay state structures.
- Follow-up: API specification should be split into `current implemented endpoints` and `target endpoints`, because most non-user tables are not yet implemented on the backend.
